<!-- START REVOLUTION SLIDER 5.0 -->

 <!--
	#################################
		- THEMEPUNCH BANNER -
	#################################
	-->
	<div class="tp-banner-container wow fadeIn" data-wow-duration="1s" data-wow-delay="1.5s">
		<div class="tp-banner" >
			<ul>

			<!-- SLIDE  -->
			<li data-transition="fade" data-slotamount="7" data-masterspeed="1000"  data-fstransition="zoomout" data-fsmasterspeed="1000" data-fsslotamount="7">  
			<!-- MAIN IMAGE -->
 			<!-- LAYERS -->

			<!-- LAYER NR. 1 -->
			 <div class="tp-caption tp-fade fadeout fullscreenvideo"
				data-x="0"
				data-y="0"
				data-speed="1000"
				data-start="1100"
				data-easing="Power4.easeOut"
				data-endspeed="1500"
				data-endeasing="Power4.easeIn"
				data-autoplay="true"
				data-autoplayonlyfirsttime="false"
				data-nextslideatend="true"
				data-forceCover="1"
				data-dottedoverlay="twoxtwo"
				data-aspectratio="16:9"
				data-forcerewind="on"
				style="z-index: 2"
				fullScreenOffsetContainer: ""> 


				<video autoplay="true" muted loop width="100%" height="100%">
					<source src='videos/INTRO BANNER 3 4 web.mp4' type='video/mp4' />
				</video>

			</div> 
		</li> 

				<!-- SLIDE  -->
				
					<!-- MAIN IMAGE 
					<img src="imagenes/home/black1.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                    <!-- LAYERS -->

					<!-- LAYER NR. 4 -->
					

					<!-- LAYER NR. texto iso -->
					

					<!-- LAYER NR. texto GPTW -->
					

					<!-- LAYER NR. texto GPTW -->
					

					<!-- LAYER NR. 7 -->
					

					
					<!-- LAYER NR. 9 -->
					

					<!-- LAYER NR. 13 -->
					

				
					<!-- LAYER NR. 20 -->
					
				
	<!-- SLIDE  -->
		<!-- <li data-transition="slidehorizontal" data-slotamount="7" data-masterspeed="1000"  data-fstransition="fade" data-fsmasterspeed="1000" data-fsslotamount="7"> -->
			<!-- MAIN IMAGE -->
			<!-- <img src="images/video_forest.jpg"  alt="video_forest"  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat"> -->
			<!-- LAYERS -->

			<!-- LAYER NR. 1 -->
			<!-- <div class="tp-caption tp-fade fadeout fullscreenvideo"
				data-x="0"
				data-y="0"
				data-speed="1000"
				data-start="1100"
				data-easing="Power4.easeOut"
				data-endspeed="1500"
				data-endeasing="Power4.easeIn"
				data-autoplay="true"
				data-autoplayonlyfirsttime="false"
				data-nextslideatend="true"
				data-forceCover="1"
				data-dottedoverlay="twoxtwo"
				data-aspectratio="16:9"
				data-forcerewind="on"
				style="z-index: 2">


				 <video class="video-js vjs-default-skin" preload="none" width="100%" height="100%"
				poster='' data-setup="{}">
				<source src='videos/moburama jancheik.mp4' type='video/mp4' />
				</video>

			</div> -->
		


		
		

				<!-- SLIDE 2 CAPITAL HUMANO -->
				
					<!-- MAIN IMAGE -->
					
					<!-- LAYERS -->
                   
					<!-- LAYER NR. 1 -->
					

					

					<!-- LAYER NR.  -->
					

					<!-- LAYER NR.  -->
					
            
					<!-- LAYER NR.  -->
					

                

				<!-- SLIDE 3 PAYROLL -->
				
					<!-- MAIN IMAGE -->
					
					<!-- LAYERS -->
					<!-- LAYER NR. 1 -->
					

					

					<!-- LAYER NR.  -->
					

					<!-- LAYER NR.  -->
					
            
					<!-- LAYER NR.  -->
					
                
			</ul>
		</div>
	</div>
<!-- fin de slider revolution -->


