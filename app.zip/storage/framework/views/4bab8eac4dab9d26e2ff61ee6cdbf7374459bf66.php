<section id="content-initText">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1>Aviso de privacidad</h1>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>