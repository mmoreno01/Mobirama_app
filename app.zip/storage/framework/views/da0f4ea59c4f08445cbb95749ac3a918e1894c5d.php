<?php $__env->startSection('content'); ?>

<div class="container">
        <h1>prueba sweetalert</h1>
    <div class="row">
        <div class="col-md-6">
                <div class="form-group">
                        <a href="prueba" class="btn btn-primary"> enviar alert</a>
            
                </div>
        </div>
        @inlude('sweet::alert')
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>