<?php $__env->startSection('content'); ?>


<section id="content-dashboard">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h1>Bienvenido <?php echo e(auth()->user()->name); ?></h1>
                        <h2 class="card-title">Email: <?php echo e(auth()->user()->email); ?></h2>
                        <form  method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-danger">Cerrar sesion</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<section id="editar_vacante">
    <div class="container">
            <?php echo $__env->make('common.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <form method="POST" action="/dashboard/<?php echo e($vacantes->id); ?>/editar">
        <?php echo method_field('PUT'); ?>
       <?php echo e(csrf_field()); ?>

            <div class="row d-flex justify-content-center">
                <div class="col-md-6"> 
                        <div class="card-header text-center">
                             <i class="fas fa-user-edit d-inline"></i>
                            <h3 class=" d-inline">Editar la vacante</h3>
                        </div>
                        <div class="form-group">
                            <label for="titulo">Titulo</label>
                            <input type="text" class="form-control" name="titulo" value="<?php echo e($vacantes->titulo); ?>">
                        </div>
                        <div class="form-group">
                            <label for="edad">Edad</label>
                            <input type="text" class="form-control" name="edad" value="<?php echo e($vacantes->edad); ?>">
                        </div>
                        <div class="form-group">
                            <label for="descripcion">Estudios</label>
                            <input type="text" class="form-control" name="descripcion" value="<?php echo e($vacantes->descripcion); ?>"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="experiencia">Experiencia Laboral</label>
                            <input type="text" class="form-control" name="experiencia" value="<?php echo e($vacantes->experiencia); ?>"></textarea>
                        </div>
                         <div class="form-group">
                                    <button class="btn btn-success  w-100">Actualizar</button>
                        </div>
                </div>
            </form>
        </div>
</section> 


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>