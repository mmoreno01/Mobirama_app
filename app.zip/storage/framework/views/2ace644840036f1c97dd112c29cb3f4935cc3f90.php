<?php $__env->startSection('content'); ?>
<!-- imagen principal -->
<div class=" parallax uk-height-large uk-background-cover uk-light uk-flex uk-flex-top wow fadeIn" data-wow-duration="1s" data-wow-delay="1s" uk-parallax="bgy: -200" style="background-image: url('imagenes/Master-Servicios-assets/Bolsa-Trabajo.jpg');">
    <div class="overlay"></div>
    <h1 class="uk-width-1-2@m uk-text-center uk-margin-auto uk-margin-auto-vertical wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.3s" uk-parallax="y: 100,0">Integrate a Nuestro Equipo</h1>
</div>
<!-- fin de la imagen principal -->
<section id="Form-contact" class="wow fadeInDown" data-wow-duration="1s" data-wow-delay="1.3s">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 form-postulation">
                <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('common.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <h1>POSTÚLATE AHORA</h1>
                    <?php echo Form::open(['route' => 'contacto.bolsaTrabajo', 'method' => 'POST', 'files' => true ]); ?>

                    <?php echo csrf_field(); ?>
                      <div class="row">
                          <div class="col-md-6 col-sm-12 p-3">
                                <div class="form-group">
                                    <?php echo Form::text('nombre', null, [ 'class' => 'form-control', 'placeholder' => 'Nombre'] ); ?>

                                </div>
                          </div>
                          <div class="col-md-6 col-sm-12 p-3">
                                <div class="form-group">
                                    <?php echo Form::text('apellido', null, [ 'class' => 'form-control', 'placeholder' => 'Apellidos'] ); ?>

                                </div>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-md-12 p-3">
                                <div class="form-group">
                                    <?php echo Form::email('correo', null, [ 'class' => 'form-control', 'placeholder' => 'Correo'] ); ?>

                                </div>
                          </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6 col-sm-12 p-3">
                            <div class="form-group">
                                    <?php echo Form::tel('telefono', null, [  'class' => 'form-control', 'placeholder' => 'Teléfono'] ); ?>

                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 p-3">
                            <div class="form-group">
                                    <?php echo Form::number('edad', null, [ 'class' => 'form-control', 'placeholder' => 'Edad'] ); ?>

                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                                <?php echo Form::label('*Añadir CV.', null, ['class' => 'control-label form-group'] ); ?>

                                <?php echo Form::file('image'); ?>

                      </div>
                    <div class="form-group">
                                    <?php echo Form::submit('Enviar', ['class' => 'btn btn-primary']); ?>

                    </div>
                <?php echo Form::close(); ?>

            </div>
            
            <div class="col-sm-12 col-md-12 col-lg-6 content-vacantesVierw">
                <div class="content-title">
                    <h2 class="">Nuestras vacantes</h2>
                </div>
        
                <?php $__currentLoopData = $vacantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-header">
                        <h1 class="card-title" style="font-size: 20px;">  <?php echo e($vacante->titulo); ?> </h1>
                    </div>
                    <div class="card-body">   
                        <h3 style="font-weight: bold; text-transform: uppercase; font-size: 15px; margin-top: 0px; margin:0px;">Edad </h3>
                                <p style="margin: 10px 0px;"> <?php echo e($vacante->edad); ?></p>
                        <h3 style="font-weight: bold; text-transform: uppercase; font-size: 15px; margin-top: 0px; margin:0px;">descripcion </h3>
                                <p style="margin: 10px 0px;"> <?php echo e($vacante->descripcion); ?> </p>
                        <h3 style="font-weight: bold; text-transform: uppercase; font-size: 15px; margin-top: 0px; margin:0px;">experiencia </h3>
                                <p style="margin: 10px 0px;"> <?php echo e($vacante->experiencia); ?> </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <?php echo e($vacantes->links()); ?>  
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>