<?php $__env->startSection('content'); ?>
<section id="panel-acceso" style="background-image: url('imagenes/nosotros/abouts-us.jpg'); background-position: center center; background-origin: cover; background-repeat: no-repeat; background-size: cover; position: relative;">
<div class="bg-overlay"></div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 content-card">
            <div class="card">
                    <div class="card-header">
                            <h3 class="card-title text-center">Acceso a la aplicacion</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST"  action="<?php echo e(route('login')); ?>">
                                <?php echo e(csrf_field()); ?>

                            <div class="form-group  <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                                <label for="user">Usuario</label>
                                <input  class="form-control" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Ingresa tu email">
                                    <?php echo $errors->first('email', '<span class="help-block">:message</span>'); ?>

                            </div>
                            <div class="form-group  <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                                    <label for="password">Contraseña</label>
                                    <input  class="form-control" type="password" name="password" placeholder="Ingresa tu password">
                                    <?php echo $errors->first('password', '<span class="help-block">:message</span>'); ?>

                            </div>
                            <button class="btn btn-primary btn-block">Acceso</button>
                        </form>
                  </div>
            </div>
        </div>
    </div>
</div>
</section>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>