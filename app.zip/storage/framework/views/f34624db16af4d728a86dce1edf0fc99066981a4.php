<?php $__env->startSection('content'); ?>


<section id="content-dashboard">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h1>Bienvenido <?php echo e(auth()->user()->name); ?></h1>
                        <h2 class="card-title">Email: <?php echo e(auth()->user()->email); ?></h2>
                        <form  method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <button class="btn btn-danger">Cerrar sesion</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section id="form_vacante">
    <div class="container">
            <?php echo $__env->make('common.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <form class="" method="POST" action="<?php echo e(route('dashboard')); ?>">
         <?php echo csrf_field(); ?>
            <div class="row d-flex justify-content-center">
                <div class="col-md-6"> 
                    <div class="card-header text-center">
                            <i class="fas fa-user-plus d-inline"></i>
                           <h3 class=" d-inline">Crear vacante</h3>
                    </div>
                        <div class="form-group">
                            <label for="titulo">Titulo</label>
                            <input type="text" class="form-control" name="titulo" required>
                        </div>
                        <div class="form-group">
                            <label for="edad">Edad</label>
                            <input type="text" class="form-control" name="edad" required>
                        </div>
                        <div class="form-group">
                            <label for="descripcion">Estudios</label>
                            <textarea type="text" class="form-control" name="descripcion" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="experiencia">Experiencia Laboral</label>
                            <textarea type="text" class="form-control" name="experiencia" required></textarea>
                        </div>
                         <div class="form-group ">
                                    <button class="btn btn-success  w-100">Publicar</button>
                        </div>
                </div>
            </div>
        </form>
    </div>
</section>




<section id="table_vacantes">
    <div class="container">
            <h2 class="text-center">Tabla de administracion de vacantes</h2>
        <div class="row">
            <div class="col-md-12">

         
        <table class="table">
            <thead>
                <th scope="col">Titulo</th>
                <th scope="col">Edad</th>
                <th scope="col">Preparacion</th>
                <th scope="col">Experiencia</th>
                <th scope="col">Accion</th>

            </thead>
            <tbody>
                <?php $__currentLoopData = $vacantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($vacante->titulo); ?></td>
                    <td><?php echo e($vacante->edad); ?></td>
                    <td><?php echo e($vacante->descripcion); ?></td>
                    <td><?php echo e($vacante->experiencia); ?></td>
                    <td> 
                        <a href="/dashboard/<?php echo e($vacante->id); ?>/editar" class="btn btn-warning btn-xs">Editar</a>
                    </td>
                    <td>
                        <form method="POST" action="dashboard/<?php echo e($vacante->id); ?>">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                            <button class="btn btn-danger btn-xs">Eliminar </button>                     
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
           </div>
        </div>    
    </div>
</section>


<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>