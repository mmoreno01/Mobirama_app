<!-- <?php $__env->startSection('services'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <p>titulo</p>
        <i class="fab fa-adn"></i>  
        </div>
        <div class="col-md-4">
            <p>titulo</p>
        <i class="fab fa-adn"></i>  
        </div>
        <div class="col-md-4">
            <p>titulo</p>
        <i class="fab fa-adn"></i>  
        </div>
    </div>
</div> -->
<div class="owl-carousel">
                          <div>
                            <i class="fab fa-adn"></i>  
                           <img src="imagenes/carousel/toyota.png" class="w-100" alt="">
                              <P>payroll</P>
                          </div>
                          <div> 
                            <i class="fab fa-adn"></i>  
                           <img src="imagenes/carousel/toyota.png" class="w-100" alt="">
                              <P>payroll</P>
                          </div>
                          <div> 
                            <i class="fab fa-adn"></i>  
                          <img src="imagenes/carousel/toyota.png" class="w-100" alt="">
                              <P>payroll</P>
                          </div>
                          <div> 
                            <i class="fab fa-adn"></i>  
                             <img src="imagenes/carousel/toyota.png" class="w-100" alt="">
                              <P>payroll</P>
                          </div>
                          <div> 
                            <i class="fab fa-adn"></i>  
                            <img src="imagenes/carousel/toyota.png" class="w-100" alt="">
                              <P>payroll</P>
                          </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>